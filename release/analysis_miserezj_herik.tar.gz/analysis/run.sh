java -classpath soot-2.5.0.jar:./bin ch.ethz.pa.Verifier ExampleTest
