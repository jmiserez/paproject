
public class LineNumberTest {
	public static void test() {
		AircraftControl ac = new AircraftControl();
		ac = new AircraftControl();ac = new AircraftControl();ac = new AircraftControl();ac = new AircraftControl();ac = new AircraftControl();
	}
}
