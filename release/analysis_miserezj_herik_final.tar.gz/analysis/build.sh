mkdir -p bin
javac -d bin -classpath soot-2.5.0.jar src/*.java src/ch/ethz/pa/*.java src/ch/ethz/pa/*/*.java


