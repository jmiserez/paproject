
Verifier is the class that needs to do verification.

To run.

1) first build using build.sh (on Linux) or just type the commands from it in Windows.
2) then run with run.sh

An eclipse project is also included, so you should be able to directly use it as well.


Do not forget to test with other examples - not only the ones in TestClass1. You will be evaluated on more complex programs.
